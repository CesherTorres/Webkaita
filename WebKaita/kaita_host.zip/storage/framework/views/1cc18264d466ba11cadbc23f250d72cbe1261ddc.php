<div class="modal fade" id="createmotivos" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white py-2">
                <span class="modal-title" id="staticBackdropLabel">Nuevo motivo de movimiento</span>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-center">
                    <p class="">Para agregar un nuevo motivo de movimiento, ponerse en contacto con el desarrollador.</p>
                    <img src="svg/programador.svg" class="pb-3" width="300" alt="">
                </div>
                
            </div>
        </div>
    </div>
</div><?php /**PATH /home/customer/www/neptundata.com/resources/views/configuracion-de-almacen/motivos/create.blade.php ENDPATH**/ ?>